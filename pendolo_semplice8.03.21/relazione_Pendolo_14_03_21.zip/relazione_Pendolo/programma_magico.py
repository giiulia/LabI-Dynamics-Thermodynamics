# -*- coding: utf-8 -*-
"""
Created on Fri Mar  5 16:48:29 2021

@author: giuly
"""

import numpy as np
from matplotlib import pyplot as plt

#codice necessario per esportare grafici per latex
import matplotlib
#decommentare per grafici belli
#matplotlib.use("pgf")
#imposta il font per essere uguale a quello di latex. potrebbe non funzionare se eseguito su anaconda
# matplotlib.rcParams.update({
#    "pgf.texsystem": "pdflatex",
 #   'font.family': 'serif',
  #  'text.usetex': True,
   # 'pgf.rcfonts': False,
#})

# from scipy.stats import chi2
import dati 
from strumenti_utili_v1 import *


#=======================    parte A1 e A2    =======================
array_dati = np.array(dati.data1)

#calcolo la media
media = np.sum(array_dati)/array_dati.size
print('le medie : m={0:.3f}'.format(media)) #uguale a np.mean

#calcolo la deviazione standard
dev = deviazione(array_dati, media)
print('la deviazione standard sulle misure è: dev={0:.3f}'.format(dev)) #più imparziale di np.std

# calcolo l'errore sulla media
Errore = dev/np.sqrt(array_dati.size)
print('errore standard sulla media: Errore={0:.3f}'.format(Errore))

print('x = {0:.3f} ± {1:.3f}'.format(media,Errore))

#istogramma a barre
min_array = np.floor(10.*min(array_dati))/10 #barbatrucco per arrontondare per difetto (floor) a decimali
max_array = np.ceil(10.*max(array_dati))/10
n = (max_array-min_array)*2/dev #numero degli intervalli
h = int(round(n))
print(h)
plt.hist(array_dati, bins = h, range = [min_array, max_array], alpha = 0.8, density=True, label='data', color='MediumAquamarine')

plt.xlabel('$x_k$ (s)')
plt.ylabel('Densità di Frequenza') 

#distribuzione gaussiana
t = np.linspace(min_array,max_array) # questa funzione definisce un vettore ad alta densità (50 numeri) per calcolare la funzione da disegnare lungo l'asse x
plt.plot(t,gaus(t,media, dev),label=r"$G(x;\bar{T},\sigma)$", color = "darkOrange")

plt.legend()
#salva immagine in formato .pgf (importabile da latex) e in png
#plt.savefig('computed_data/hist_and_gauss.pgf')
plt.savefig('computed_data/hist_and_gauss.png')
plt.show()

#calcolo del chi quadro
chi = chi_sq(dati.data1, media, dev)
print('il chi quadro per la gaussiana risulta: chi = {0:.3f}'.format(chi))

d = 3
chi_ridotto = chi/d #chi quadro ridotto
print('consultare la tabella delle probabilità relative al chi quadro con chi ridotto = {0:.2f} relativo a {1:.0f} gradi di libertà'.format(chi_ridotto, d))
# pchi_ridotto = 1-chi2.cdf(chi_ridotto,d)
# print('P(chi_ridotto) = {:.1f}%'.format(100.*pchi_ridotto))

#=======================    parte A3    =======================
array_dati = np.array(dati.dataD1)/10
print(array_dati)

#calcolo la media
media = np.sum(array_dati)/array_dati.size
print('la media è: m={}'.format(media)) #uguale a np.mean


#calcolo la deviazione standard
dev = deviazione(array_dati, media)
print('la deviazione standard sulle misure è: dev={}'.format(dev)) #più imparziale di np.std

# calcolo l'errore sulla media
Errore = dev/np.sqrt(array_dati.size)
print('errore standard sulla media: Errore={}'.format(Errore))

print('T10 = {0:.3f} ± {1:.3f}'.format(media,Errore))

#=======================    parte B    =======================

y = np.array([
    np.mean(dati.dataD1),
     np.mean(dati.dataD2),
    np.mean(dati.dataD3),
    np.mean(dati.dataD4),
    ])
print(y)
y = y/10
print(y)


x = np.array([
    np.mean(dati.datal1),
    np.mean(dati.datal2),
    np.mean(dati.datal3),
    np.mean(dati.datal4),
])
print(x)


#calcolo il coefficiente
p = x * np.power(y, 2)
#print(np.power(y, 2))
powerx = np.power(x, 2)
coefficiente = np.sum(p)/np.sum(powerx)

#calcolo l'incertezza sulle y
temp = np.power(np.power(y, 2) - (coefficiente*x), 2)
sigma_y = np.sqrt(sum(temp))/np.sqrt(y.size-1)
print('incertezza sulle y = {}'.format(sigma_y))

#calcolo sigma coefficiente
sigma_B = sigma_y/np.sqrt(sum(powerx))
print('il coefficiente B è uguale a {0:.3f} ± {1:.3f}'.format(coefficiente, sigma_B))

g = (4*np.power(np.pi, 2))/coefficiente
print('accelerazione di gravità: {}'.format(g))

#interpolazione dei dati e retta
plt.errorbar(x, np.power(y,2), sigma_y, fmt='o', ls='none', label='data')

plt.xlim(left=0)
plt.ylim(bottom=0)

xmin = 0
xmax = max(x)+0.1*(max(x)-min(x))
t = np.linspace(xmin,xmax) # stessa funzione ad alta densità
plt.plot(t,line(t,coefficiente),label=r"$y = {:.2f}x$".format(coefficiente), color="darkOrange")
plt.plot(t,line(t,coefficiente))
plt.legend() # aggiungo una legenda
#plt.savefig('computed_data/retta.pgf')
plt.savefig('computed_data/retta.png')
plt.show()
#=======================    generazione tabelle   =======================
#tabella lunghezze
#crea_tabella(dati.datal, 15, "computed_data/tableLength.tex")
#tabella masse
#crea_tabella(dati.datam, 15, "computed_data/tableMass.tex", "centrata")
#tabella periodo
#crea_tabella(dati.dataT1, 15, "computed_data/tablePeriod1.tex", "centrata")

